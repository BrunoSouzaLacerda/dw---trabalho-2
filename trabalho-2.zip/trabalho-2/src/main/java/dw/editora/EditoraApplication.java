package dw.editora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EditoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(EditoraApplication.class, args);
	}

}
