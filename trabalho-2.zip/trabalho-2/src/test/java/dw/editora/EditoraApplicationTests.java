package dw.editora;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EditoraApplicationTests {

	@Test
	void contextLoads() {
	}

}
